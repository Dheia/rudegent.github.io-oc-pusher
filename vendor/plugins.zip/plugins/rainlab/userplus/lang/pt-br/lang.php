<?php

return [
    'plugin' => [
        'name' => 'Usuário Plus+',
        'description' => 'Adiciona campos de perfil aos usuários.',
    ],
    'tab' => [
        'profile' => 'Perfil',
    ],
    'user' => [
        'phone' => 'Telefone',
        'mobile' => 'Celular',
        'company' => 'Empresa',
        'city' => 'Cidade',
        'zip' => 'Cep',
        'street_addr' => 'Endereço',
    ],
];
