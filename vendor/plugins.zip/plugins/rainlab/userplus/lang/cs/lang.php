<?php

return [
    'plugin' => [
        'name' => 'User Plus+',
        'description' => 'Přidává uživatelům profilová políčka.',
    ],
    'tab' => [
        'profile' => 'Profil',
    ],
    'user' => [
        'phone' => 'Telefon',
        'mobile' => 'Mobil',
        'company' => 'Firma',
        'city' => 'Město',
        'zip' => 'PSČ',
        'street_addr' => 'Ulice',
    ],
];
