<?php

return [
    'plugin' => [
        'name' => 'Üye Plus+',
        'description' => 'Üyeler için ek profil bilgileri sağlar.',
    ],
    'tab' => [
        'profile' => 'Profil',
    ],
    'user' => [
        'phone' => 'Telefon',
        'mobile' => 'Cep telefon',
        'company' => 'Firma',
        'city' => 'Şehir',
        'zip' => 'Posta kodu',
        'street_addr' => 'Adresi',
    ],
];
