<?php
return [
    'plugin' => [
        'name' => 'User Plus+',
        'description' => 'Ajoute des champs de profil aux utilisateurs.',
    ],
    'user' => [
        'phone' => 'Téléhone',
        'mobile' => 'Mobile',
        'company' => 'Société',
        'city' => 'Ville',
        'zip' => 'Code postal',
        'street_addr' => 'Addresse',
    ],
];
