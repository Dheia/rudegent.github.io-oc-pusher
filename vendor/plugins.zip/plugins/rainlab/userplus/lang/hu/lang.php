<?php

return [
    'plugin' => [
        'name' => 'Felhasználók Plusz+',
        'description' => 'Új személyes mezők a felhasználók adatlapjához.',
    ],
    'tab' => [
        'profile' => 'Személyes',
    ],
    'user' => [
        'phone' => 'Telefon',
        'mobile' => 'Mobil',
        'company' => 'Cég',
        'city' => 'Város',
        'zip' => 'Irszám.',
        'street_addr' => 'Postacím',
    ],
];
