<?php

return [
    'plugin' => [
        'name' => 'گسترش کاربر',
        'description' => 'افزودن فیلد به پروفایل کاربران',
    ],
    'user' => [
        'phone' => 'تلفن',
        'mobile' => 'تلفن همراه',
        'company' => 'شرکت',
        'city' => 'شهر',
        'zip' => 'کد پستی',
        'street_addr' => 'آدرس',
    ],
];
