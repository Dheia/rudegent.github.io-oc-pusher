<?php return [
    'plugin' => [
        'name' => 'Money',
        'description' => 'Everything you need to have installed to work with money in your OctoberCMS app'
    ],
    'currency_form' => [
        'fraction_digits' => 'Number of fraction digits',
    ],
];
