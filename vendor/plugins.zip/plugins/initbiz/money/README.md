# Money - Plugin to use money in OctoberCMS painlessly. 
![Money banner](https://raw.githubusercontent.com/initbizlab/initbizlab.github.io/master/money/assets/images/money-banner.png)

This is a repo of OctoberCMS plugin by [InIT.biz](https://www.init.biz).

For full documentation visit [https://docs.init.biz/money/](https://docs.init.biz/money/) or go to [OctoberCMS's marketplace](https://octobercms.com/plugin/initbiz-money).
